package Skelebash;

public class Blocked {

    public static boolean[][] blocked;

    public static boolean[][] getblocked() {
        return blocked;
    }
};
